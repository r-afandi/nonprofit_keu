export interface Periode {
  id: string;
  nama: string;
  mulai: string;
  akhir: string;
}

export interface KategoriAkun {
  id: string;
  no: string;
  nama: string;
  kategori: string;
  type: string;
  prefix: string;
}

export interface Akun {
  id: string;
  no: string;
  kode: string;
  kategoriId: string;
  nama: string;
  jenisAnggaran: string;
  saldo: number;
  isKasBank: boolean;
  isRestrict: boolean;
}

export interface JournalEntry {
  id: string;
  akun: string;
  debit: number;
  credit: number;
}

export interface Pemasukan {
  id: string;
  tanggal: string;
  deskripsi: string;
  nominal: number;
  buktiTransaksi?: string;
  status: 'draft' | 'posted' | 'revised';
  journalEntries: JournalEntry[];
  createdAt: string;
  updatedAt: string;
}

export interface Pengeluaran {
  id: string;
  tanggal: string;
  deskripsi: string;
  nominal: number;
  buktiTransaksi?: string;
  status: 'draft' | 'posted' | 'revised';
  journalEntries: JournalEntry[];
  createdAt: string;
  updatedAt: string;
}
