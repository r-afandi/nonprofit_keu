import { ReactNode } from 'react'
import { cn } from '@/lib/utils'

interface SummaryCardProps {
  title: string
  value: string | number
  subtitle?: string
  icon?: ReactNode
  variant?: 'default' | 'success' | 'warning' | 'danger'
}

export function SummaryCard({
  title,
  value,
  subtitle,
  icon,
  variant = 'default'
}: SummaryCardProps) {
  const bgVariants = {
    default: 'bg-blue-50',
    success: 'bg-green-50',
    warning: 'bg-orange-50',
    danger: 'bg-red-50'
  }

  const textVariants = {
    default: 'text-blue-600',
    success: 'text-green-600',
    warning: 'text-orange-600',
    danger: 'text-red-600'
  }

  return (
    <div className={cn('rounded-lg p-6', bgVariants[variant])}>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className={cn('mt-2 text-2xl font-bold', textVariants[variant])}>
            {typeof value === 'number' 
              ? `Rp ${value.toLocaleString('id-ID')}`
              : value
            }
          </p>
          {subtitle && (
            <p className="mt-1 text-xs text-gray-500">{subtitle}</p>
          )}
        </div>
        {icon && (
          <div className={cn('rounded-lg p-3', bgVariants[variant])}>
            <div className={cn('h-6 w-6', textVariants[variant])}>
              {icon}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
