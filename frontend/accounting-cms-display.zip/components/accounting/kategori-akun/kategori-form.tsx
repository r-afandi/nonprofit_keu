'use client'

import { useState } from 'react'
import { KategoriAkun } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

interface KategoriFormProps {
  kategori?: KategoriAkun
  onSubmit: (data: Omit<KategoriAkun, 'id'>) => void
  isLoading?: boolean
}

export function KategoriForm({
  kategori,
  onSubmit,
  isLoading = false,
}: KategoriFormProps) {
  const [formData, setFormData] = useState<Omit<KategoriAkun, 'id'>>({
    no: kategori?.no || '',
    nama: kategori?.nama || '',
    kategori: kategori?.kategori || 'Aktiva',
    type: kategori?.type || 'Debit',
    prefix: kategori?.prefix || '',
  })

  const [errors, setErrors] = useState<Record<string, string>>({})

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.no.trim()) {
      newErrors.no = 'No harus diisi'
    }
    if (!formData.nama.trim()) {
      newErrors.nama = 'Nama harus diisi'
    }
    if (!formData.prefix.trim()) {
      newErrors.prefix = 'Prefix harus diisi'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (validateForm()) {
      onSubmit(formData)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="no">No</Label>
        <Input
          id="no"
          value={formData.no}
          onChange={(e) => setFormData({ ...formData, no: e.target.value })}
          placeholder="Contoh: 001"
          className={errors.no ? 'border-red-500' : ''}
        />
        {errors.no && <p className="mt-1 text-sm text-red-500">{errors.no}</p>}
      </div>

      <div>
        <Label htmlFor="nama">Nama</Label>
        <Input
          id="nama"
          value={formData.nama}
          onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
          placeholder="Contoh: Kas"
          className={errors.nama ? 'border-red-500' : ''}
        />
        {errors.nama && <p className="mt-1 text-sm text-red-500">{errors.nama}</p>}
      </div>

      <div>
        <Label htmlFor="kategori">Kategori</Label>
        <Select value={formData.kategori} onValueChange={(value) => setFormData({ ...formData, kategori: value })}>
          <SelectTrigger id="kategori">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Aktiva">Aktiva</SelectItem>
            <SelectItem value="Pasiva">Pasiva</SelectItem>
            <SelectItem value="Modal">Modal</SelectItem>
            <SelectItem value="Pendapatan">Pendapatan</SelectItem>
            <SelectItem value="Beban">Beban</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="type">Type</Label>
        <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
          <SelectTrigger id="type">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Debit">Debit</SelectItem>
            <SelectItem value="Kredit">Kredit</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="prefix">Prefix</Label>
        <Input
          id="prefix"
          value={formData.prefix}
          onChange={(e) => setFormData({ ...formData, prefix: e.target.value })}
          placeholder="Contoh: KAS"
          className={errors.prefix ? 'border-red-500' : ''}
        />
        {errors.prefix && <p className="mt-1 text-sm text-red-500">{errors.prefix}</p>}
      </div>

      <Button type="submit" disabled={isLoading} className="w-full">
        {isLoading
          ? 'Menyimpan...'
          : kategori
            ? 'Update Kategori'
            : 'Tambah Kategori'}
      </Button>
    </form>
  )
}
