'use client'

import { useState } from 'react'
import { Akun, KategoriAkun } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

interface AkunFormProps {
  akun?: Akun
  kategoriList: KategoriAkun[]
  onSubmit: (data: Omit<Akun, 'id'>) => void
  isLoading?: boolean
}

export function AkunForm({
  akun,
  kategoriList,
  onSubmit,
  isLoading = false,
}: AkunFormProps) {
  const [formData, setFormData] = useState<Omit<Akun, 'id'>>({
    no: akun?.no || '',
    kode: akun?.kode || '',
    kategoriId: akun?.kategoriId || '',
    nama: akun?.nama || '',
    jenisAnggaran: akun?.jenisAnggaran || 'Operasional',
    saldo: akun?.saldo || 0,
    isKasBank: akun?.isKasBank || false,
    isRestrict: akun?.isRestrict || false,
  })

  const [errors, setErrors] = useState<Record<string, string>>({})

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.no.trim()) {
      newErrors.no = 'No harus diisi'
    }
    if (!formData.kode.trim()) {
      newErrors.kode = 'Kode harus diisi'
    }
    if (!formData.kategoriId) {
      newErrors.kategoriId = 'Kategori akun harus dipilih'
    }
    if (!formData.nama.trim()) {
      newErrors.nama = 'Nama akun harus diisi'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (validateForm()) {
      onSubmit(formData)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="no">No</Label>
        <Input
          id="no"
          value={formData.no}
          onChange={(e) => setFormData({ ...formData, no: e.target.value })}
          placeholder="Contoh: 001"
          className={errors.no ? 'border-red-500' : ''}
        />
        {errors.no && <p className="mt-1 text-sm text-red-500">{errors.no}</p>}
      </div>

      <div>
        <Label htmlFor="kode">Kode</Label>
        <Input
          id="kode"
          value={formData.kode}
          onChange={(e) =>
            setFormData({ ...formData, kode: e.target.value })
          }
          placeholder="Contoh: KAS-001"
          className={errors.kode ? 'border-red-500' : ''}
        />
        {errors.kode && <p className="mt-1 text-sm text-red-500">{errors.kode}</p>}
      </div>

      <div>
        <Label htmlFor="kategori">Kategori Akun</Label>
        <Select
          value={formData.kategoriId}
          onValueChange={(value) =>
            setFormData({ ...formData, kategoriId: value })
          }
        >
          <SelectTrigger
            id="kategori"
            className={errors.kategoriId ? 'border-red-500' : ''}
          >
            <SelectValue placeholder="Pilih kategori" />
          </SelectTrigger>
          <SelectContent>
            {kategoriList.map((kategori) => (
              <SelectItem key={kategori.id} value={kategori.id}>
                {kategori.nama} ({kategori.prefix})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {errors.kategoriId && (
          <p className="mt-1 text-sm text-red-500">{errors.kategoriId}</p>
        )}
      </div>

      <div>
        <Label htmlFor="nama">Nama Akun</Label>
        <Input
          id="nama"
          value={formData.nama}
          onChange={(e) =>
            setFormData({ ...formData, nama: e.target.value })
          }
          placeholder="Contoh: Kas Kecil"
          className={errors.nama ? 'border-red-500' : ''}
        />
        {errors.nama && <p className="mt-1 text-sm text-red-500">{errors.nama}</p>}
      </div>

      <div>
        <Label htmlFor="jenis">Jenis Anggaran</Label>
        <Select
          value={formData.jenisAnggaran}
          onValueChange={(value) =>
            setFormData({ ...formData, jenisAnggaran: value })
          }
        >
          <SelectTrigger id="jenis">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Operasional">Operasional</SelectItem>
            <SelectItem value="Investasi">Investasi</SelectItem>
            <SelectItem value="Pembiayaan">Pembiayaan</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="saldo">Saldo Awal</Label>
        <Input
          id="saldo"
          type="number"
          value={formData.saldo}
          onChange={(e) =>
            setFormData({ ...formData, saldo: parseFloat(e.target.value) })
          }
          placeholder="0"
        />
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Checkbox
            id="isKasBank"
            checked={formData.isKasBank}
            onCheckedChange={(checked) =>
              setFormData({ ...formData, isKasBank: checked as boolean })
            }
          />
          <Label htmlFor="isKasBank" className="cursor-pointer">
            Adalah Kas/Bank
          </Label>
        </div>
        <div className="flex items-center gap-2">
          <Checkbox
            id="isRestrict"
            checked={formData.isRestrict}
            onCheckedChange={(checked) =>
              setFormData({ ...formData, isRestrict: checked as boolean })
            }
          />
          <Label htmlFor="isRestrict" className="cursor-pointer">
            Dibatasi (Restrict)
          </Label>
        </div>
      </div>

      <Button type="submit" disabled={isLoading} className="w-full">
        {isLoading
          ? 'Menyimpan...'
          : akun
            ? 'Update Akun'
            : 'Tambah Akun'}
      </Button>
    </form>
  )
}
