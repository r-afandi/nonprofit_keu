'use client'

import { Akun, KategoriAkun } from '@/lib/types'
import { Button } from '@/components/ui/button'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Edit2, Trash2 } from 'lucide-react'

interface AkunTableProps {
  akunList: Akun[]
  kategoriList: KategoriAkun[]
  onEdit: (akun: Akun) => void
  onDelete: (id: string) => void
}

export function AkunTable({
  akunList,
  kategoriList,
  onEdit,
  onDelete,
}: AkunTableProps) {
  const getKategoriName = (kategoriId: string) => {
    return kategoriList.find((k) => k.id === kategoriId)?.nama || '-'
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
    }).format(amount)
  }

  if (akunList.length === 0) {
    return (
      <div className="flex items-center justify-center rounded-lg border border-dashed border-gray-300 py-12">
        <p className="text-gray-500">Tidak ada data akun</p>
      </div>
    )
  }

  return (
    <div className="rounded-lg border border-gray-200">
      <Table>
        <TableHeader>
          <TableRow className="bg-gray-50">
            <TableHead className="font-semibold">No</TableHead>
            <TableHead className="font-semibold">Kode</TableHead>
            <TableHead className="font-semibold">Akun</TableHead>
            <TableHead className="font-semibold">Kategori</TableHead>
            <TableHead className="font-semibold">Jenis Anggaran</TableHead>
            <TableHead className="text-right font-semibold">Saldo</TableHead>
            <TableHead className="text-right font-semibold">Opsi</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {akunList.map((akun) => (
            <TableRow key={akun.id} className="hover:bg-gray-50">
              <TableCell className="text-gray-600">{akun.no}</TableCell>
              <TableCell className="font-mono text-sm font-medium">
                {akun.kode}
              </TableCell>
              <TableCell className="font-medium">{akun.nama}</TableCell>
              <TableCell className="text-gray-600">
                {getKategoriName(akun.kategoriId)}
              </TableCell>
              <TableCell className="text-gray-600">
                {akun.jenisAnggaran}
              </TableCell>
              <TableCell className="text-right font-medium text-green-600">
                {formatCurrency(akun.saldo)}
              </TableCell>
              <TableCell className="text-right">
                <div className="flex items-center justify-end gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onEdit(akun)}
                    className="text-blue-600 hover:bg-blue-50"
                  >
                    <Edit2 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      if (
                        confirm(
                          'Apakah Anda yakin ingin menghapus akun ini?'
                        )
                      ) {
                        onDelete(akun.id)
                      }
                    }}
                    className="text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
