'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { LayoutDashboard, TrendingUp, TrendingDown, PieChart, BarChart3, Settings } from 'lucide-react'
import { cn } from '@/lib/utils'

export function Sidebar() {
  const pathname = usePathname()

  const menuItems = [
    {
      label: 'Dashboard',
      href: '/accounting/dashboard',
      icon: LayoutDashboard,
    },
    {
      label: 'Pemasukan',
      href: '/accounting/pemasukan',
      icon: TrendingUp,
      submenu: [
        { label: 'Input', href: '/accounting/pemasukan' },
        { label: 'Riwayat', href: '/accounting/pemasukan/riwayat' },
        { label: 'Laporan', href: '/accounting/pemasukan/laporan' },
      ]
    },
    {
      label: 'Pengeluaran',
      href: '/accounting/pengeluaran',
      icon: TrendingDown,
      submenu: [
        { label: 'Input', href: '/accounting/pengeluaran' },
        { label: 'Riwayat', href: '/accounting/pengeluaran/riwayat' },
        { label: 'Laporan', href: '/accounting/pengeluaran/laporan' },
      ]
    },
    {
      label: 'Anggaran',
      href: '/accounting/anggaran',
      icon: PieChart,
    },
    {
      label: 'Laporan',
      href: '/accounting/laporan',
      icon: BarChart3,
    },
    {
      label: 'Pengaturan',
      href: '/accounting/pengaturan',
      icon: Settings,
    },
  ]

  const isActive = (href: string) => pathname === href || pathname.startsWith(href + '/')

  return (
    <aside className="w-64 border-r border-gray-200 bg-white h-screen flex flex-col">
      <div className="flex h-16 items-center border-b border-gray-200 px-6">
        <h1 className="text-xl font-semibold text-gray-900">Akuntansi</h1>
      </div>
      <nav className="flex-1 space-y-1 p-4 overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon
          const active = isActive(item.href)
          return (
            <div key={item.href}>
              <Link
                href={item.href}
                className={cn(
                  'flex items-center gap-3 rounded-lg px-4 py-2.5 text-sm font-medium transition-colors',
                  active
                    ? 'bg-blue-50 text-blue-600'
                    : 'text-gray-700 hover:bg-gray-50'
                )}
              >
                <Icon className="h-5 w-5" />
                {item.label}
              </Link>
              {item.submenu && active && (
                <div className="ml-4 mt-1 space-y-1">
                  {item.submenu.map((sub) => (
                    <Link
                      key={sub.href}
                      href={sub.href}
                      className={cn(
                        'block rounded-lg px-4 py-2 text-xs font-medium transition-colors',
                        pathname === sub.href
                          ? 'text-blue-600 bg-blue-50'
                          : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                      )}
                    >
                      {sub.label}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          )
        })}
      </nav>
    </aside>
  )
}
