'use client'

import { useState, useEffect } from 'react'
import { Akun } from '@/lib/types'

const STORAGE_KEY = 'akun'

const initialData: Akun[] = [
  {
    id: '1',
    no: '001',
    kode: 'KAS-001',
    kategoriId: '1',
    nama: 'Kas Kecil',
    jenisAnggaran: 'Operasional',
    saldo: 5000000,
    isKasBank: true,
    isRestrict: false,
  },
  {
    id: '2',
    no: '002',
    kode: 'BNK-001',
    kategoriId: '2',
    nama: 'Bank BCA',
    jenisAnggaran: 'Operasional',
    saldo: 50000000,
    isKasBank: true,
    isRestrict: false,
  },
  {
    id: '3',
    no: '003',
    kode: 'UTG-001',
    kategoriId: '3',
    nama: 'Utang Supplier',
    jenisAnggaran: 'Operasional',
    saldo: 10000000,
    isKasBank: false,
    isRestrict: true,
  },
]

export function useAkun() {
  const [akunList, setAkunList] = useState<Akun[]>([])
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored) {
      try {
        setAkunList(JSON.parse(stored))
      } catch {
        setAkunList(initialData)
        localStorage.setItem(STORAGE_KEY, JSON.stringify(initialData))
      }
    } else {
      setAkunList(initialData)
      localStorage.setItem(STORAGE_KEY, JSON.stringify(initialData))
    }
    setIsLoaded(true)
  }, [])

  const addAkun = (akun: Omit<Akun, 'id'>) => {
    const newAkun: Akun = {
      ...akun,
      id: Date.now().toString(),
    }
    const updated = [...akunList, newAkun]
    setAkunList(updated)
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated))
    return newAkun
  }

  const updateAkun = (id: string, akun: Omit<Akun, 'id'>) => {
    const updated = akunList.map((a) => (a.id === id ? { id, ...akun } : a))
    setAkunList(updated)
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated))
  }

  const deleteAkun = (id: string) => {
    const updated = akunList.filter((a) => a.id !== id)
    setAkunList(updated)
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated))
  }

  const searchAkun = (query: string) => {
    return akunList.filter(
      (a) =>
        a.nama.toLowerCase().includes(query.toLowerCase()) ||
        a.kode.toLowerCase().includes(query.toLowerCase()) ||
        a.no.includes(query)
    )
  }

  return {
    akunList,
    isLoaded,
    addAkun,
    updateAkun,
    deleteAkun,
    searchAkun,
  }
}
