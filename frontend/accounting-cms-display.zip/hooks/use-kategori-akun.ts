'use client'

import { useState, useEffect } from 'react'
import { KategoriAkun } from '@/lib/types'

const STORAGE_KEY = 'kategori_akun'

const initialData: KategoriAkun[] = [
  {
    id: '1',
    no: '001',
    nama: 'Kas',
    kategori: 'Aktiva',
    type: 'Debit',
    prefix: 'KAS',
  },
  {
    id: '2',
    no: '002',
    nama: 'Bank',
    kategori: 'Aktiva',
    type: 'Debit',
    prefix: 'BNK',
  },
  {
    id: '3',
    no: '003',
    nama: 'Utang',
    kategori: 'Pasiva',
    type: 'Kredit',
    prefix: 'UTG',
  },
]

export function useKategoriAkun() {
  const [kategoriList, setKategoriList] = useState<KategoriAkun[]>([])
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored) {
      try {
        setKategoriList(JSON.parse(stored))
      } catch {
        setKategoriList(initialData)
        localStorage.setItem(STORAGE_KEY, JSON.stringify(initialData))
      }
    } else {
      setKategoriList(initialData)
      localStorage.setItem(STORAGE_KEY, JSON.stringify(initialData))
    }
    setIsLoaded(true)
  }, [])

  const addKategori = (kategori: Omit<KategoriAkun, 'id'>) => {
    const newKategori: KategoriAkun = {
      ...kategori,
      id: Date.now().toString(),
    }
    const updated = [...kategoriList, newKategori]
    setKategoriList(updated)
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated))
    return newKategori
  }

  const updateKategori = (id: string, kategori: Omit<KategoriAkun, 'id'>) => {
    const updated = kategoriList.map((k) =>
      k.id === id ? { id, ...kategori } : k
    )
    setKategoriList(updated)
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated))
  }

  const deleteKategori = (id: string) => {
    const updated = kategoriList.filter((k) => k.id !== id)
    setKategoriList(updated)
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated))
  }

  const searchKategori = (query: string) => {
    return kategoriList.filter(
      (k) =>
        k.nama.toLowerCase().includes(query.toLowerCase()) ||
        k.kategori.toLowerCase().includes(query.toLowerCase()) ||
        k.prefix.toLowerCase().includes(query.toLowerCase())
    )
  }

  return {
    kategoriList,
    isLoaded,
    addKategori,
    updateKategori,
    deleteKategori,
    searchKategori,
  }
}
