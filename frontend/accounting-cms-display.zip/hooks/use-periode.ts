'use client'

import { useState, useEffect } from 'react'
import { Periode } from '@/lib/types'

const STORAGE_KEY = 'periodes'

const initialData: Periode[] = [
  {
    id: '1',
    nama: 'Periode 2024',
    mulai: '2024-01-01',
    akhir: '2024-12-31',
  },
  {
    id: '2',
    nama: 'Periode 2025',
    mulai: '2025-01-01',
    akhir: '2025-12-31',
  },
]

export function usePeriode() {
  const [periodes, setPeriodes] = useState<Periode[]>([])
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored) {
      try {
        setPeriodes(JSON.parse(stored))
      } catch {
        setPeriodes(initialData)
        localStorage.setItem(STORAGE_KEY, JSON.stringify(initialData))
      }
    } else {
      setPeriodes(initialData)
      localStorage.setItem(STORAGE_KEY, JSON.stringify(initialData))
    }
    setIsLoaded(true)
  }, [])

  const addPeriode = (periode: Omit<Periode, 'id'>) => {
    const newPeriode: Periode = {
      ...periode,
      id: Date.now().toString(),
    }
    const updated = [...periodes, newPeriode]
    setPeriodes(updated)
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated))
    return newPeriode
  }

  const updatePeriode = (id: string, periode: Omit<Periode, 'id'>) => {
    const updated = periodes.map((p) => (p.id === id ? { id, ...periode } : p))
    setPeriodes(updated)
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated))
  }

  const deletePeriode = (id: string) => {
    const updated = periodes.filter((p) => p.id !== id)
    setPeriodes(updated)
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated))
  }

  const searchPeriode = (query: string) => {
    return periodes.filter(
      (p) =>
        p.nama.toLowerCase().includes(query.toLowerCase()) ||
        p.mulai.includes(query) ||
        p.akhir.includes(query)
    )
  }

  return {
    periodes,
    isLoaded,
    addPeriode,
    updatePeriode,
    deletePeriode,
    searchPeriode,
  }
}
